/*
4coder_jumping.h - Typesused when writing code to jump to locations and seek through jump lists.
*/

// TOP

#if !defined(FCODER_JUMPING_H)
#define FCODER_JUMPING_H

typedef u32 Jump_Flag;
enum{
    JumpFlag_SkipSubs = 1,
};

#endif

// BOTTOM