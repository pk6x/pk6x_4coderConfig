/*
4coder_build_commands.h - Commands for building types.
*/

// TOP

#if !defined(FCODER_BUILD_COMMANDS_H)
#define FCODER_BUILD_COMMANDS_H

#endif

// BOTTOM