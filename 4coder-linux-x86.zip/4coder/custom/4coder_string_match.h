/*
 * Mr. 4th Dimention - Allen Webster
 *
 * 30.07.2019
 *
 * Types for operating on the String_Match and String_Match_List types.
 *
 */

// TOP

#if !defined(FCODER_STRING_MATCH_H)
#define FCODER_STRING_MATCH_H

typedef b32 Buffer_Predicate(Application_Links *app, Buffer_ID buffer);

#endif

// BOTTOM