Thank you for contributing to the 4coder project!

To submit bug reports or to request particular features post them here:
https://github.com/4coder-editor/4coder/issues

For questions email:
editor@4coder.net

Sign up for the newsletter for the most critical 4coder news:
newsletter.4coder.net

Watch the 4coder.handmade.network blog and @AllenWebster4th twitter for news about 4coder.

For documentation, feature lists, and more visit the home page:
4coder.net


